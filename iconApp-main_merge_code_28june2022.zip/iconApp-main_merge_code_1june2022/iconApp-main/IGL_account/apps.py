from django.apps import AppConfig


class IglAccountConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'IGL_account'
