from django.db import models
from icon.models import Icon, IconTeam
from games.models import Game
# from autoslug import AutoSlugField
from games.models import Platform
import pytz


# Create your models here.

class TournamentFormateIn(models.Model):
    type = models.CharField(max_length=256, null=True, blank=True)

    def __str__(self):
        return self.type


class MyTimezoneTableIn(models.Model):
    ALL_TIMEZONES = sorted((item, item) for item in pytz.all_timezones)
    tz_name = models.CharField(choices=ALL_TIMEZONES, max_length=65)

    def __str__(self):
        return self.tz_name


class TournamentLengthIn(models.Model):
    hour = models.CharField(max_length=51, null=True, blank=True)

    def __str__(self):
        return self.hour


class TournamentSetupIn(models.Model):

    CHECKED_IN_CHOICES = (
        ('yes', 'yes'),
        ('no', 'no'),
    )

    TEAM_EVENT = (
        ('yes', 'yes'),
        ('no', 'no'),
    )

    THIRD_GAME_CHOICES = (
        ('yes', 'yes'),
    )

    PARTICIPANT_PLACEMENT_CHOICES = (
        ('Autofill', 'Autofill'),
    )

    name = models.CharField(max_length=151, unique=True)
    tournament_host = models.ForeignKey(Icon, on_delete=models.PROTECT)
    # slug = AutoSlugField(populate_from='full_name', unique_with='scheduled_date_start')
    platform = models.ManyToManyField(Platform, blank=True)
    game = models.ForeignKey(Game, on_delete=models.SET_NULL, null=True)
    highest_index_eligible = models.FloatField(null=True, blank=True)
    team_member_only = models.BooleanField(null=True, blank=True)
    Tournament_start_date = models.DateField()
    Tournament_start_time = models.TimeField()
    timezone = models.ForeignKey(MyTimezoneTableIn, on_delete=models.PROTECT)
    checked_in_at = models.CharField(max_length=3, choices=CHECKED_IN_CHOICES)
    registration_open_date = models.DateTimeField()
    registration_close_date = models.DateTimeField()
    team_event = models.CharField(max_length=8, choices=TEAM_EVENT)
    max_players_team = models.PositiveSmallIntegerField()
    tournament_structure = models.ForeignKey(TournamentFormateIn, on_delete=models.PROTECT)
    max_player_participants = models.PositiveIntegerField()
    tournament_open_to = models.ForeignKey(IconTeam, on_delete=models.PROTECT)
    entry_fee = models.PositiveIntegerField()
    third_place_game = models.CharField(max_length=3, choices=THIRD_GAME_CHOICES, null=True, blank=True)
    participants_placement = models.CharField(max_length=8, choices=PARTICIPANT_PLACEMENT_CHOICES, null=True, blank=True)
    tournament_length = models.ForeignKey(TournamentLengthIn, on_delete=models.PROTECT, null=True, blank=True)
    points_per_kill = models.IntegerField(null=True, blank=True)
    first_place = models.IntegerField(null=True, blank=True)
    second_place = models.IntegerField(null=True, blank=True)
    third_place = models.IntegerField(null=True, blank=True)
    fourth_place = models.IntegerField(null=True, blank=True)
    fifth_place = models.IntegerField(null=True, blank=True)
    first_prize_image = models.ImageField(default='', upload_to='admin', blank=True, null=True)
    second_prize_image = models.ImageField(default='', upload_to='admin', blank=True, null=True)
    third_prize_image = models.ImageField(default='', upload_to='admin', blank=True, null=True)

    def __str__(self):
        return self.name
