from django.urls import path
from Admin_app.views import UserOtpView, AdminLoginView, AdminProfileView, AdminRegistrationView, TournamentSetupAPI


urlpatterns = [
    path('admin_login/', AdminLoginView.as_view(), name='admin_login'),
    path('otp/', UserOtpView.as_view(), name='otp'),
    path('admin_profile/', AdminProfileView.as_view(), name='admin_profile'),
    path('admin_register/', AdminRegistrationView.as_view(), name='register'),
    path('tournament_setup/', TournamentSetupAPI.as_view(), name='register'),

]
