from django.contrib import admin
from .models import TournamentSetupIn, TournamentFormateIn, MyTimezoneTableIn, TournamentLengthIn
# Register your models here.

admin.site.register(TournamentFormateIn)
admin.site.register(MyTimezoneTableIn)
admin.site.register(TournamentLengthIn)
admin.site.register(TournamentSetupIn)


