from django.contrib import admin

from .models import Challenge, ChallengeStatus, ChallengeOutcome, GameMode, DirectChallenge, Opponent, OpenChallenge


class ChallengeAdmin(admin.ModelAdmin):
    list_display = (
        'challenger',
        'recipient',
        'status',
        'responded_at',
        'game',
        'entry_fee',
        'outcome',
        'total_winnings',
    )


class ChallengeOutcomeAdmin(admin.ModelAdmin):
    list_display = (
        'challenge',
        'winner',
        'total_winnings',
    )


class DirectChallengeAdmin(admin.ModelAdmin):
    list_display = (
        'Opponent',
        'entry_fee',
        'game_mode',
    )


class OpenChallengeAdmin(admin.ModelAdmin):
    list_display = (
        'entry_fee',
        'game_mode',
    )


admin.site.register(ChallengeStatus)
admin.site.register(Challenge, ChallengeAdmin)
admin.site.register(ChallengeOutcome, ChallengeOutcomeAdmin)
admin.site.register(GameMode)
admin.site.register(DirectChallenge, DirectChallengeAdmin)
admin.site.register(Opponent)
admin.site.register(OpenChallenge, OpenChallengeAdmin)
