from .models import Challenge, ChallengeOutcome, DirectChallenge, OpenChallenge
from rest_framework import serializers
from django_filters import rest_framework as filters
from games.serializer import GameSerializer


class ChallengeSerializer(serializers.ModelSerializer):
    outcome = serializers.PrimaryKeyRelatedField(read_only=True)
    status =  serializers.StringRelatedField()
    platforms = serializers.StringRelatedField(many=True)
    game = serializers.StringRelatedField()
    challenger = serializers.StringRelatedField()
    recipient = serializers.StringRelatedField()

    class Meta:
        model = Challenge
        fields = [
            'id',
            'status',
            'challenger',
            'recipient',
            'entry_fee',
            'game',
            'platforms',
            'is_open',
            'sent_at',
            'responded_at',
            'outcome',
        ]


class CreateChallengeSerializer(serializers.ModelSerializer):
    outcome = serializers.PrimaryKeyRelatedField(read_only=True)

    class Meta:
        model = Challenge
        fields = [
            'id',
            'status',
            'challenger',
            'recipient',
            'entry_fee',
            'game',
            'platforms',
            'is_open',
            'sent_at',
            'responded_at',
            'outcome',
        ]


class ChallengeOutcomeSerializer(serializers.ModelSerializer):
    challenge = serializers.StringRelatedField()
    winner = serializers.StringRelatedField()

    class Meta:
        model = ChallengeOutcome
        fields = [
            'id',
            'challenge',
            'winner',
            'submitted_at',
            'total_winnings',
        ]


class CreateChallengeOutcomeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChallengeOutcome
        fields = [
            'id',
            'challenge',
            'winner',
            'submitted_at',
            'total_winnings',
        ]


class ChallengeResponseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Challenge
        fields = [
            'responded_at',
            'status',
        ]


class ChallengeFilter(filters.FilterSet):
    min_entry_fee = filters.NumberFilter(field_name="entry_fee", lookup_expr='gte')
    max_entry_fee = filters.NumberFilter(field_name='entry_fee', lookup_expr='lte')

    class Meta:
        model = Challenge
        fields = [
            'entry_fee',
            'game',
            'platforms',
            'is_open',
            'min_entry_fee',
            'max_entry_fee'
        ]


class DirectChallengeSerializer(serializers.ModelSerializer):
    platforms = serializers.StringRelatedField(many=True)
    game = GameSerializer()
    Opponent = serializers.StringRelatedField()
    game_mode = serializers.StringRelatedField()

    class Meta:
        model = DirectChallenge
        fields = [
            'id',
            'platforms',
            'game',
            'Opponent',
            'entry_fee',
            'game_mode',
        ]


class CreateDirectChallengeSerializer(serializers.ModelSerializer):
    class Meta:
        model = DirectChallenge
        fields = [
            'id',
            'platforms',
            'game',
            'Opponent',
            'entry_fee',
            'game_mode',
        ]


class OpenChallengeSerializer(serializers.ModelSerializer):
    platforms = serializers.StringRelatedField(many=True)
    game = GameSerializer()
    opponent = serializers.StringRelatedField()
    game_mode = serializers.StringRelatedField()

    class Meta:
        model = OpenChallenge
        fields = [
            'id',
            'platforms',
            'game',
            'opponent',
            'entry_fee',
            'game_mode',
        ]


class CreateOpenChallengeSerializer(serializers.ModelSerializer):
    class Meta:
        model = OpenChallenge
        fields = [
            'id',
            'platforms',
            'game',
            'opponent',
            'entry_fee',
            'game_mode',
        ]
