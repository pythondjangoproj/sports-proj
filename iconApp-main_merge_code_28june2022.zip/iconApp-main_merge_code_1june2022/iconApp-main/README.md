# iconApp
Icon Gamer League Backend Application

This application comprises the Django application backend for the Icon Gamer League. 

The "game" module contains internal objects that will map to the toornament.com API. 
https://developer.toornament.com/v2/overview/get-started
